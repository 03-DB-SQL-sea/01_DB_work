package Uebungen._600_690;

// Loop Label

// Schreibe das Label raus.

public class _640_LoopLabel {

    public static void main(String[] args) {

        int counter = 0;
        for (int i = 1; i <= 10; i++) {
            loop:
            for (int j = 1; j <= 10; j++) {
                for (int k = 1; k <= 10; k++) {
                    if (j == 5) break loop;  // 400
                    counter++;
                }
            }
        }
        System.out.println(counter);
    }
}

