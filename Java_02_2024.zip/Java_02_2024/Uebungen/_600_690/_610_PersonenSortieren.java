package Uebungen._600_690;

import java.util.ArrayList;
import java.util.Collections;

public class _610_PersonenSortieren {

    /*
     * Personen sortieren
     *
     * Übernehme die Klassen Person und Mitarbeiter aus der Aufgabe Personen.
     * Implementiere in der Klasse Person das Interface Comparable.
     * Es soll zuerst nach Nachname sortiert werden,
     * dann nach Vorname und zuletzt absteigend nach Alter.
     * Teste es mit der Klasse Mitarbeiter und unten stehender main()-Methode.
     */
/*
    public static void main(String[] args) {

        Mitarbeiter m1 = new Mitarbeiter("Peter", "Wellert", 29);
        Mitarbeiter m2 = new Mitarbeiter("Paul", "Wellert", 29);
        Mitarbeiter m3 = new Mitarbeiter("Mary", "Wellert", 29);
        Mitarbeiter m4 = new Mitarbeiter("Peter", "Wellert", 19);
        Mitarbeiter m5 = new Mitarbeiter("Peter", "Wellert", 39);
        Mitarbeiter m6 = new Mitarbeiter("Peter", "Sommer", 33);
        Mitarbeiter m7 = new Mitarbeiter("Steve", "Beck", 23);

        ArrayList<Mitarbeiter> mitarbeiter = new ArrayList<>();
        mitarbeiter.add(m1);mitarbeiter.add(m2);mitarbeiter.add(m3);mitarbeiter.add(m4);
        mitarbeiter.add(m5);mitarbeiter.add(m6);mitarbeiter.add(m7);

        System.out.println(mitarbeiter);
        // [Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Peter', nachname='Wellert', alter=29}
        // , Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Paul', nachname='Wellert', alter=29}
        // , Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Mary', nachname='Wellert', alter=29}
        // , Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Peter', nachname='Wellert', alter=19}
        // , Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Peter', nachname='Wellert', alter=39}
        // , Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Peter', nachname='Sommer', alter=33}
        // , Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Steve', nachname='Beck', alter=23}
        // ]

        Collections.sort(mitarbeiter);
        System.out.println(mitarbeiter);
        // [Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Steve', nachname='Beck', alter=23}
        // , Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Peter', nachname='Sommer', alter=33}
        // , Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Mary', nachname='Wellert', alter=29}
        // , Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Paul', nachname='Wellert', alter=29}
        // , Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Peter', nachname='Wellert', alter=39}
        // , Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Peter', nachname='Wellert', alter=29}
        // , Mitarbeiter{mitarbeiterNummer=0, abteilung=''} Person{vorname='Peter', nachname='Wellert', alter=19}
        // ]
    }
*/
}
