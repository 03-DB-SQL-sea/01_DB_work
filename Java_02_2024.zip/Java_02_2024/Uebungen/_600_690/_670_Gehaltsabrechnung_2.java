package Uebungen._600_690;

public class _670_Gehaltsabrechnung_2 {

    /*
     * Gehaltsabrechnung 2
     *
     * Dies Aufgabe baut auf die Aufgabe Gehaltsabrechnung auf.
     *
     * 4.
     * Implementiere die abstrakte Klasse Abrechnung und ihre beiden Unterklassen
     * LohnAbrechnung und GehaltsAbrechnung nach folgendem Grundriss:
     *
     *   public abstract class Abrechnung {
     *       private int periode;
     *       private Mitarbeiter mitarbeiter;
     *       public Abrechnung(int periode, Mitarbeiter m) { ... }
     *       public int getPeriode() { ... }
     *       public Mitarbeiter getMitarbeiter() { ... }
     *       public abstract double getVerdienst();
     *       public String toString() { ... }
     *   }
     *
     *   public class GehaltsAbrechnung extends Abrechnung {
     *       private double gehalt;
     *       public GehaltsAbrechnung(int periode,
     *                                Mitarbeiter m,
     *                                double gehalt) { ... }
     *       public double getVerdienst() { ... }
     *   }
     *
     *   public class LohnAbrechnung extends Abrechnung {
     *       private double stundenLohn;
     *       private double anzahlStunden;
     *       public LohnAbrechnung(int periode,
     *                             Mitarbeiter m,
     *                             double stundenlohn,
     *                             int stunden) { ... }
     *       public double getVerdienst() { ... }
     *   }
     *
     * Sowohl Lohn- als auch Gehaltsabrechnung erfolgen in einer Abrechnungsperiode
     * (in der Regel eine fortlaufend durchnummerierte Periodenummer)
     * und referenzieren einen Mitarbeiter.
     * Die abstrakte Methode getVerdienst() in der Klasse Abrechnung gibt in dem konkreten Fall
     * den Verdienst eines Mitarbeiters in der entsprechenden Periode zurück.
     * Bei einer Gehaltsabrechnung ist dies das Gehalt,
     * bei einer Lohnabrechnung ist es das Produkt aus Stundenlohn
     * und Anzahl der geleisteten Stunden.
     * Die toString()-Methode in Abrechnung soll die Periodennummer,
     * den Namen des Mitarbeiters und den Verdienst als String zurückgeben
     * (Hinweis: Verwende für letzteres die getVerdienst()-Methode)
     *
     * 5.
     * Erweiter die Klasse PersonalVerwaltung dahingehend,
     * dass analog zu den Mitarbeitern auch Abrechnungen hinzugefügt und entfernt werden können,
     * und schreibe eine Methode listAbrechnungen(),
     * welche alle Abrechnungen einer bestimmten Abrechnungsperiode auf der Konsole ausgibt.
     *
     * 6.
     * Java bietet zum Sortieren die statische Methode Collections.sort().
     * Verwende diese zum Sortieren der Mitarbeiterliste,
     * sodass du auf deine eigene Bubblesort-Implementierung verzichten kannst.
     * Damit dies funktioniert,
     * muss die Klasse Mitarbeiter das Interface Comparable implementieren.
     * Es ist demnach eine Methode int compareTo(Mitarbeiter m) erforderlich,
     * deren Rückgabewert sich im Prinzip verhält wie die compareTo()-Methode der Klasse String.
     * Im Anschluss kannst du die ist Kleiner()-Methode auskommentieren,
     * da sie quasi durch die compareTo()-Methode ersetzt wird.
     * Du kannst am Ende folgendes Testprogramm verwenden:
     *
     * public static void main(String[] args) {
     *   PersonalVerwaltung pv = new PersonalVerwaltung();
     *   Mitarbeiter m1 = new Mitarbeiter("Josef Maier");
     *   pv.addMitarbeiter(m1);
     *   Mitarbeiter m2 = new Mitarbeiter("Franz Huber");
     *   pv.addMitarbeiter(m2);
     *   Mitarbeiter m3 = new Mitarbeiter("Werner Müller");
     *   pv.addMitarbeiter(m3);
     *   pv.sortMitarbeiter();
     *   pv.listMitarbeiter();
     *   pv.addAbrechnung(new LohnAbrechnung(1,m1,10,158));
     *   pv.addAbrechnung(new GehaltsAbrechnung(1,m2,3010));
     *   pv.addAbrechnung(new GehaltsAbrechnung(1,m3,2700));
     *   pv.addAbrechnung(new LohnAbrechnung(2,m1,16,158));
     *   pv.addAbrechnung(new GehaltsAbrechnung(2,m2,3010));
     *   pv.addAbrechnung(new GehaltsAbrechnung(2,m3,2800));
     *   pv.listAbrechnungen(2);
     * }
     *
     * und solltest dann in etwa diese Ausgabe in der Konsole erhalten:
     *
     *  Mitarbeiter
     *  2, Franz Huber
     *  1, Josef Maier
     *  3, Werner Müller
     *
     *  Abrechnungen
     *  2, Josef Maier, 2528.0
     *  2, Franz Huber, 3010.0
     *  2, Werner Müller, 2800.0
     */
}
