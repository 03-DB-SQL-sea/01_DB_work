package Uebungen._600_690._690_PersonStudentTeacher;

public class PersonStudentTeacherPart2 {

    /*
     * Part 2: Student
     *
     * Create a class Student, which inherits the class Person.
     *
     * At creation, a student has 0 study credits.
     * Every time a student studies, the amount of study credits goes up.
     * The class must act as follows:
     */
     // Student ollie = new Student("Ollie", "6381 Hollywood Blvd. Los Angeles 90028");
     // System.out.println(ollie);
     // System.out.println("Study credits " + ollie.credits());
     // ollie.study();
     // System.out.println("Study credits "+ ollie.credits());
     /*
     * Sample output:
     * Ollie
     *   6381 Hollywood Blvd. Los Angeles 90028
     * Study credits 0
     * Study credits 1
     */

}
