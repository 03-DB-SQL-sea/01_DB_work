package Uebungen._600_690._690_PersonStudentTeacher;

public class PersonStudentTeacherPart4 {

    /*
     * Part 4: Teacher
     *
     * Create a class Teacher, which inherits the class Person.
     *
     * The class must act as follows:
     */
     // Teacher ada = new Teacher("Ada Lovelace", "24 Maddox St. London W1S 2QN", 1200);
     // Teacher esko = new Teacher("Esko Ukkonen", "Mannerheimintie 15 00100 Helsinki", 5400);
     // System.out.println(ada);
     // System.out.println(esko);
     //
     // Student ollie = new Student("Ollie", "6381 Hollywood Blvd. Los Angeles 90028");
     //
     // int i = 0;
     // while (i < 25) {
     //   ollie.study();
     //   i = i + 1;
     // }
     // System.out.println(ollie);
     /*
     * Sample output:
     * Ada Lovelace
     *   24 Maddox St. London W1S 2QN
     *   salary 1200 euro/month
     * Esko Ukkonen
     *   Mannerheimintie 15 00100 Helsinki
     *   salary 5400 euro/month
     * Ollie
     *   6381 Hollywood Blvd. Los Angeles 90028
     *   Study credits 25
     */
}
