package Uebungen._600_690._690_PersonStudentTeacher;

public class PersonStudentTeacherPart1 {

    /*
     * Part 1: Person
     *
     * Create a class Person. The class must work as follows:
     */
     // Person ada = new Person("Ada Lovelace", "24 Maddox St. London W1S 2QN");
     // Person esko = new Person("Esko Ukkonen", "Mannerheimintie 15 00100 Helsinki");
     // System.out.println(ada);
     // System.out.println(esko);
     /*
     * Sample output:
     * Ada Lovelace
     *   24 Maddox St. London W1S 2QN
     * Esko Ukkonen
     *   Mannerheimintie 15 00100 Helsinki
     */
}
