package Uebungen._600_690._690_PersonStudentTeacher;

public class PersonStudentTeacherPart5 {

    /*
     * List all Persons
     *
     * Write a method public static void printPersons(ArrayList<Person> persons) in the Main class.
     * The method prints all the persons on the list given as the parameter.
     * The method must act as follows when invoked from the main method:
     */
     // public static void main(String[] args) {
     //     ArrayList<Person> persons = new ArrayList<Person>();
     //     persons.add(new Teacher("Ada Lovelace", "24 Maddox St. London W1S 2QN", 1200));
     //     persons.add(new Student("Ollie", "6381 Hollywood Blvd. Los Angeles 90028"));
     //
     //     printPersons(persons);
     // }
     /*
     * Sample output:
     * Ada Lovelace
     *   24 Maddox St. London W1S 2QN
     *   salary 1200 euro/month
     * Ollie
     *   6381 Hollywood Blvd. Los Angeles 90028
     *   Study credits 0
     */

}
