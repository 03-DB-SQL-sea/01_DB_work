package Uebungen._600_690._690_PersonStudentTeacher;

public class PersonStudentTeacherPart3 {

    /*
     * Part 3: Student's toString
     *
     * In the previous task, Student inherits the toString() method from the class Person.
     * However, you can also overwrite an inherited method, replacing it with your own version.
     * Write a version of toString() method specifically for the Student class.
     * The method must act as follows:
     */
     // Student ollie = new Student("Ollie", "6381 Hollywood Blvd. Los Angeles 90028");
     // System.out.println(ollie);
     // ollie.study();
     // System.out.println(ollie);
     /*
     * Sample output:
     * Ollie
     *   6381 Hollywood Blvd. Los Angeles 90028
     *   Study credits 0
     * Ollie
     *   6381 Hollywood Blvd. Los Angeles 90028
     *   Study credits 1
     *
     */
}
