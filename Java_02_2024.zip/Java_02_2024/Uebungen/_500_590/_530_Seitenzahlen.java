package Uebungen._500_590;

public class _530_Seitenzahlen {

    /*
     * Seitenzahlen
     *
     * Ein Schriftsetzer musste bei einem Buch die Seitenzahlen mit Lettern drucken.
     * Lettern sind spiegelverkehrte Schriftzeichen,
     * die heute nur noch selten für den Buchdruck verwendet werden.
     * Dafür musste unser Schriftsetzer wissen,
     * wie viele solcher Lettern er für die Seitennummerierung benötigt.
     * Seitennummerierungen bestehen ausschließlich aus den Ziffern 0 bis 9.
     * In dieser Aufgabe werden Lettern und Ziffern synonym verwendet.
     * Ab Seite 5 waren die Seiten nummeriert.
     * Die Seite 10 benötigt als Erste zwei Ziffern (nämlich die Ziffer "1" und die Ziffer "0").
     * Die Lettern konnten für verschiedene Seiten nicht wiederverwendet werden,
     * da alle Seiten gleichzeitig für den Druck bereitstehen mussten.
     *
     * Schreibe ein Programm,
     * das für eine gegebene Anzahl Seiten die benötigten Anzahlen für jede Ziffer ausgibt.
     * Da die Nummerierung erst bei 5 beginnt,
     * hatte ein Buch mit 4 Seiten noch keine Ziffern.
     * Ein Buch mit 11 Seiten benötigte bereits die Ziffern
     * 5 (1x), 6 (1x), 7 (1x), 8 (1x), 9 (1x), 1 (3x) und 0 (1x).
     *
     * Zur Programmierung verwende eine ArrayList von [0] bis [9] (also mit 10 Einträgen),
     * worin je die Anzahl der benötigten Ziffern steht.
     */

}
