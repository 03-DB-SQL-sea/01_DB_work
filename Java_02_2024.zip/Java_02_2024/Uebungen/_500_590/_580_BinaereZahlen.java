package Uebungen._500_590;

public class _580_BinaereZahlen {

       /*
        * Binäre Zahlen
        *
        * Schreibe ein Programm, das alle Zahlen von 0-255 binär schreibt:

        0 0 0 0 0 0 0 0
        0 0 0 0 0 0 0 1
        0 0 0 0 0 0 1 0
        0 0 0 0 0 0 1 1
        0 0 0 0 0 1 0 0
        ...
        1 1 1 1 1 0 1 1
        1 1 1 1 1 1 0 0
        1 1 1 1 1 1 0 1
        1 1 1 1 1 1 1 0
        1 1 1 1 1 1 1 1

        */
}
