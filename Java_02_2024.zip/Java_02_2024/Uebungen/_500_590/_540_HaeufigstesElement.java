package Uebungen._500_590;

public class _540_HaeufigstesElement {

    /*
     * Häufigstes Element
     *
     * Gegeben ist ein Array zum Beispiel mit Zahlen als Werten:
     * [2, 17, 10, 9, 16, 3, 9, 16, 5, 1, 17, 14]
     * Schreibe ein Programm, welches das häufigste Element eines Arrays findet.
     * Sollte das Programm mehrere Elemente gleicher Anzahl finden,
     * so darf irgend ein Element dieser Häufigsten ausgegeben werden.
     */

    /*
     * Zusatz:
     * Sollte es mehrere häufigste Elemente geben,
     * sollen alle häufigsten Elemente ausgegeben werden.
     * Auch soll die Anzahl der Vorkommnisse des häufigsten Elements ausgegeben werden.
     */

}
