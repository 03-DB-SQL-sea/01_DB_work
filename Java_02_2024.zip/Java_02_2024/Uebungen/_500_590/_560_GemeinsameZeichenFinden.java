package Uebungen._500_590;

public class _560_GemeinsameZeichenFinden {

    /*
     * Gemeinsame Zeichen finden
     *
     * Schreibe ein Programm, dass ermittelt,
     * welches die gemeinsamen Buchstaben der Zeichenketten
     * "Divide et impera" und "Teile und herrsche" sind?
     *
     */
}
