package Uebungen._400_490;

public class _440_Tage {

    public static void main(String[] args) {

        /*
         * Tage
         *
         * Berechne wieviele Tage zwischen dem 13.8.1961 und
         * dem 9.11.1989 vergangen sind (jeweils inklusive).
         */
    }
}
