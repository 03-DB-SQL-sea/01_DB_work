package Uebungen._400_490;

public class _490_SchwarzeFreitage {

    /*
     * Schwarze Freitage
     *
     * Schreibe ein Methode, mit dem alle Freitage einer beliebigen
     * Zeitspanne aufgezeigt werden, die auf einen 13. fielen.
     * Die Methode erwartet das Anfangsjahr und das Endjahr als Parameter.
     * Zusatz:
     * Ermittle, in welchen Jahren des 20. Jahrhundert, es jeweils drei schwarze Freitage gab.
     */

}
