package Uebungen._500_590;

public class _520_Sternenmuster {

    /*
     * Sternenmuster
     *
     * Schreibe ein Programm,
     * das folgende Sternchen-Muster in der Konsole ausgibt:


     * * * *
     * * * *
     * * * *

     *
     * *
     * * *
     * * * *
     * * * * *

     *
     * * *
     * * * * *
     * * * * * * *


     */
}
