package Uebungen._100_190;

public class _100_Bubblesort {

    public static void main(String[] args) {

        /*
         * Bubblesort
         *
         * Schreibe ein Methode,
         * der man ein Array mit beliebig vielen Integern als Werten übergeben kann
         * und die dieses Array sortiert und zurück gibt.
         *
         * Benutze hierzu den Bubblesort-Algorithmus.
         * Bei diesem wird das Array durchlaufen
         * und jede Zahl mit der jeweils nachfolgenden Zahl verglichen.
         * Wenn die nachfolgende Zahl kleiner ist,
         * werden die Zahlen getauscht.
         * Das Array wird solange durchlaufen,
         * bis bei einem Durchlauf keine Zahlen getauscht werden müssen.
         */

    }
}
