package Uebungen._100_190;

public class _160_EinmaligesInArrayList {

    public static void main(String[] args) {

        /*
         * Einmaliges in ArrayList
         *
         * Schreibe ein Programm, das eine ArrayList mit neun Zahlen befüllt.
         * Dabei sollen vier Zahlen doppelt vorkommen
         * und eine Zahl nur einmal.
         *
         * Mische dann die ArrayList per Collections.shuffle(ArrayList)
         *
         * Schreibe dann ein Programm, das aus dieser ArrayList die Zahl findet,
         * die nur einmal vorkommt.
         */

    }
}
