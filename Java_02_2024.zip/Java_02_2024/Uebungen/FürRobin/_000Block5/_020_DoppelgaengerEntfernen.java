//package Uebungen._300_390;
//
//public class _310_DoppelgaengerEntfernen {
//
//    public static void main(String[] args) {
//
//        /*
//         * Doppelgänger entfernen
//         *
//         * Entferne die Doppelgänger aus einer ArrayList von Zahlen
//         * (z. B. aus [1, 2, 3, 2, 7, 3, 9]).
//         * Die Ergebnisliste soll aufsteigend sortiert sein.
//         */
//    }
//}
