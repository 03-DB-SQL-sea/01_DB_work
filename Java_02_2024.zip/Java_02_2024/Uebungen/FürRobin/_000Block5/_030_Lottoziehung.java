package Uebungen._100_190;

public class _030_Lottoziehung {

    public static void main(String[] args) {

        /*
         * Lottoziehung
         *
         * Schreibe ein Programm,
         * das sechs verschiedene Lottozahlen (6 aus 49) zieht
         * und in einem Array abspeichert.
         */

    }
}
