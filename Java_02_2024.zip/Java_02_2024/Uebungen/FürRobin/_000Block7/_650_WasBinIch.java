1. Erzeuge eine Beliebige Datenklasse.
2. Erzeuge eine ShelveServiceKlasse mit den Hauptbefehlen: Insert, update, Delete und Get.
	(Zudem brauchst du noch lesen, schreiben und ggf. append) 
3. Erzeuge ein Testprogramm das die Datenklasse und die DatenbankServiceKlasse test

Benutze dafür die Vorlage aius dem 470_JSON-Ornder
