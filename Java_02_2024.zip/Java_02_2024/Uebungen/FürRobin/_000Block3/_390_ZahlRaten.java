package Uebungen._300_390;

public class _390_ZahlRaten {

    public static void main(String[] args) {

        /*
         * Zahl raten
         *
         * Schreibe ein Programm,
         * das sich eine Zahl zwischen 1 und 10 ausdenkt
         * und den Benutzer diese Zahl raten läßt.
         * Nach jedem Versuch gibt die Funktion aus,
         * ob zu hoch, zu niedrig oder richtig geraten wurde.
         * Am Ende soll ausgegeben werden, wie viele Versuche gebraucht wurden.
         */

    }
}
