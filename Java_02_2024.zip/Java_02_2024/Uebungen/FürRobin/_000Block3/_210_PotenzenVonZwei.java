package Uebungen._200_290;

public class _210_PotenzenVonZwei {

    public static void main(String[] args) {

        /*
         * Potenzen von Zwei
         *
         * Schreibe ein Programm, das alle Potenzen von 2 ausgibt
         * deren Ergebnis kleiner als 10.000 ist.
         *
         * Zusatz: Die Ausgabe soll folgendermaßen aussehen:
         * 2 ** 0 = 1
         * 2 ** 1 = 2
         * ...
         * 2 ** 12 = 4096
         * 2 ** 13 = 8192
         */

    }
}
