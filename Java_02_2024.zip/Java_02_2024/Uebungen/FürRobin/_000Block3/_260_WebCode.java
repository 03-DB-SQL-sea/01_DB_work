package Uebungen._200_290;

public class _260_WebCode {

    public static void main(String[] args) {

        /*
         * Web-Code
         *
         * Für ein Buchprojekt wird ein Web-Code benötigt.
         * Mit diesem Web-Code können Artikel direkt online abgefragt werden.
         * Der Code soll aus acht Zeichen bestehen.
         * Vorkommen dürfen Ziffern und Kleinbuchstaben.
         * Um Verwechslungen zu vermeiden,
         * kommen die Ziffer Eins (1) und der Kleinbuchstabe "ell" (l) nicht vor.
         * Ebenso kommt die Null (0) nicht vor.
         * Dass das große "Oh" (O) nicht vorkommen kann, ist klar,
         * denn die Vorgabe erlaubt nur Kleinbuchstaben.
         *
         * Schreibe ein Programm, das fünf zufällige Web-Codes erzeugt.
         */
    }
}
