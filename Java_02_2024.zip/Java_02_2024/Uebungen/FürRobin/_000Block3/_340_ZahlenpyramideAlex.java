package Uebungen._300_390;

public class _340_ZahlenpyramideAlex {

    public static void main(String[] args) {

        // Zahlenpyramide

        // Ein Programm schreiben, das folgendes Ergebnis ausgibt:
        // 0
        // 1 2
        // 2 3 4
        // 3 4 5 6
        // 4 5 6 7 8
        // 5 6 7 8 9 10
        // 6 7 8 9 10 11 12
        // 7 8 9 10 11 12 13 14
        // 8 9 10 11 12 13 14 15 16
    }
}
