package Uebungen._300_390;

public class _350_LaengsterSubstring {

    public static void main(String[] args) {

       /* Längster Substring
        *
        * Schreibe ein Programm das in einem Buchstabensalat (z.B. "sakdeidpoidweoidowijk")
        * den längsten Substring in alphabetisch-korrekter Reihenfolge findet.
        *
        * "kotafgovlav" -> "Der längste alphabetische Substring ist: afgov"
        *
        + Gibt es 2 gleichlange Kandidaten, soll der erste genommen werden
        * "acgbcf" -> "Der längste alphabetische Substring ist: acg"
        */

    }
}
