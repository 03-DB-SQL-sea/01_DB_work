package Uebungen._300_390;

public class _330_WuerfelWahrscheinlichkeit {

    public static void main(String[] args) {

        /*
         * Würfel-Wahrscheinlichkeit
         *
         * Wie groß ist die Wahrscheinlichkeit,
         * dass beim Wurf zweier Würfel die Summe der Augenzahlen 7 entspricht?
         *
         * Die Wahrscheinlichkeit dafür, dass die Summe der Augenzahlen 7 ist,
         * berechnet sich aus der Anzahl aller Würfe mit Summe 7,
         * geteilt durch die Anzahl aller möglichen Würfe.
         *
         * Zusatz:
         * Schreibe eine Methode,
         * die obige Wahrscheinlichkeit für eine beliebige Summe berechnet.
         *
         * 1-1 -> 2
         * 1-2 -> 3
         * 1-3 -> 4
         *
         * 3-4 -> 7
         * ...
         * 6-6 -> 12
         */

    }
}
