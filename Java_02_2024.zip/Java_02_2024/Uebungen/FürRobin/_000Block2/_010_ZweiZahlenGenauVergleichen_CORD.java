package Uebungen._010_090;

public class _010_ZweiZahlenGenauVergleichen_CORD {

    public static void main(String[] args) {

        /*
         * Zwei Zahlen genau vergleichen
         *
         * Schreibe ein Programm, das zwei zufällige Zahlen erzeugt.
         * Dann soll das Programm testen und ausgeben,
         * welche von zwei Zahlen größer ist oder ob beide Zahlen gleich groß sind.
         */

    }
}
