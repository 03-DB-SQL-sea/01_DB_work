package Uebungen._010_090;

public class _040_KleinsteVonDreiUnterschiedlichenZahlen {

    public static void main(String[] args) {

        /*
         * Kleinste von drei UNTERSCHIEDLICHEN Zahlen
         *
         * Schreibe ein Programm,
         * das drei Variablen mit zufälligen,
         * UNTERSCHIEDLICHEN Zahlen (aus dem gleichen Zahlenraum) befüllt.
         * Dann soll das Programm testen,
         * welche der Zahlen die Kleinste ist und diese ausgeben.
         */

    }
}
