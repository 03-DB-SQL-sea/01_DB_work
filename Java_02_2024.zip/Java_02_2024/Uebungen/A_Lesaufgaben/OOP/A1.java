package Uebungen.A_Lesaufgaben.OOP;



//    Beachte den folgenden Code:

class Student {

    public String name = "";
    public int age = 0;
    public String major = "Undeclared";
    public boolean fulltime = true;

    public void display() {
        System.out.println("Name: " + name + " Major: " + major);
    }

    public boolean isFulltime() {
        return fulltime;
    }
}

//    Welcher Code initialisiert ein Student-Objekt?
//
//        A) Student student1 = new Student();
//
//        B) Student student1 = Student.new();
//
//        C) Student student1 = Student();
//
//        D) Student student1;

public class A1 {
    public static void main(String[] args) {
        Student student1;
//        Student student1 = Student();
//        Student student1 = Student.new();
//        Student student2 = new Student();

    }
}


