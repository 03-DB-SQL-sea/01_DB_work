package Uebungen._700_790;

public class _740_KurzOderLang {

    /*
     * Kurz oder lang
     *
     * Gegeben ist ein Array mit Wörtern.
     *
     * Erzeuge daraus ein Array mit zehn Sätzen,
     * die aus drei bis siebzehn zufälligen Wörtern aus dem ersten Array bestehen sollen.
     * Der erste Buchstabe in jedem Satz soll großgeschrieben sein
     * und am Ende soll jeder Satz einen Punkt haben.
     *
     * Ermittle nun, ob in dem neuen Array zuerst einer der kürzesten
     * oder zuerst einer der längsten Sätze ist und gib diesen Satz aus.
     */

    public static void main(String[] args) {

        String[] woerter = {"es", "gibt", "im", "Moment", "in", "diese", "Mannschaft", "oh", "einige",
                "spieler", "vergessen", "ihnen", "Profi", "was", "sie", "sind", "ich", "lese", "nicht",
                "sehr", "viele", "Zeitungen", "aber", "habe", "gehört", "viele", "Situationen",
                "erstens", "wir", "haben", "nicht", "offensiv", "gespielt", "es", "keine", "deutsche",
                "Mannschaft", "spielt", "offensiv", "und", "die", "Name", "offensiv", "wie", "Bayern",
                "letzte", "spiel", "hatten", "wir", "in", "Platz", "drei", "Spitzen"};
    }

}
