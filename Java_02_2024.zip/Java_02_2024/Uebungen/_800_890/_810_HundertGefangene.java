package Uebungen._800_890;

public class _810_HundertGefangene {

    /*  Intro - Die Story:

    „Der Leiter eines Gefängnisses gibt 100 zum Tode verurteilten Gefangenen
    mit den Nummern von 1 bis 100 eine letzte Chance.

    In einem Raum befindet sich ein Schrank mit 100 Schubladen. Der Gefängnis-
    leiter legt in jede Schublade die Nummer genau eines Gefangenen in
    zufälliger Reihenfolge und schließt die Schubladen daraufhin.
    Die Gefangenen betreten den Raum der Reihe nach. Jeder Gefangene darf
    50 Schubladen in einer beliebigen Reihenfolge öffnen und muss sie danach
    mit ihrem Inhalt wieder schließen. Finden dabei alle Gefangenen ihre
    eigene Nummer in einer der Schubladen, werden die Gefangenen begnadigt.
    Findet irgendein Gefangener seine Nummer nicht, müssen alle Gefangenen
    sterben.
    Bevor der erste Gefangene den Raum betritt, dürfen sich die Gefangenen
    beraten, danach ist jedoch keinerlei Kommunikation mehr möglich. Was ist
    für die Gefangenen die beste Strategie?“
    */

    /*  Aufgabe:

    Erstelle ein Programm, mit dem die zwei Strategien getestet werden können.
    Die Anzahl der Schubladen und die der zu öffnenden Schubladen soll variabel
    sein. Zudem soll es auch möglich sein, dass die Simulation mittels einer
    Schleife mehrfach durchführbar ist. Ich schlage 1_000 Durchläufe für den
    Start vor.

    Am Ende des Durchlaufs gib aus, wie oft Strategie 1 und wie oft Strategie 2
    zum Freispruch geführt hat:

    Ausgabe auf dem Bildschirm in dieser Form:
    Strategie 1: <AnzahlFreisprueche>
    Strategie 2: <AnzahlFreisprueche>

    Starte mit den Werten, wie es in der Geschichte vorgegeben ist (100 / 50).
    Teste auch andere Werte. Spannend ist auch, was sich bei 2 / 1 ergibt.
    (5 / 1) und (100 / 90) sind auch interessant.

    Hinweis: Dadurch dass die Simulationen mehrfach (1 - n mal) durchläuft,
    müsst Ihr Eure Variableninhalte im Auge behalten.
    */

    /*  Struktur
    Erstelle vier Klassen: DerRaum, DerSchrank, Strategie1 & Strategie2.
    (Die jeweiligen Methoden sollen statisch sein)

            DerRaum:
                - ist die Hauptklasse
                - Führe 1_000 Durchgänge durch und zähle, wie oft welche
                    Strategie zum Freispruch aller führt.

            DerSchrank:
                - Erstelle einen Schrank mit n Schubladen
                - Fülle die Schubladen zufällig mit Werten von 1 bis n
                    (hierbei dürfen natürlich keine doppelten Werte vorkommen)

            Strategie1:
                - Jeder Gefangene wählt eine zufällige Schublade
                    (Achte darauf, dass eine bereits geöffnete Schublade
                    nicht nochmal geöffnet werden kann)

            Strategie2:
                - Der Gefangene öffnet als Erstes die Schublade, die seiner
                    Gefangenennummer entspricht. Der Wert, der in dieser
                    Schublade gefunden wird, ist die Nummer der nächsten
                    Schublade, die der Gefangene öffnet (etc.)
    */


    /*  Outro

    Nachdem Du die statistische Auswertung der Strategien gesehen hast, sage
    einfach "Whooooooooot tf". Danach überprüfe, ob Dein Code richtig funktio-
    niert und sage dann nochmal "Whooooooooot tf"...

    Tipp:
    Fange nicht an zu überlegen, warum das so ist. Akzeptiere es einfach, oder
    verfalle möglicherweise dem Wahnsinn. =8-)

    Viel Erfolg und ganz viel Spaß!!!

    Weiterführende Informationen und Quelle:
    https://de.wikipedia.org/wiki/Problem_der_100_Gefangenen
    */


    /* Quellcode Beispiel für DerRaum (Als Hilfestellung)

    Der Quellcode dient lediglich der Orientierung. Dein Lösungsansatz kann
    anders aussehen. Daher schau hier nur drauf, wenn Du nicht weißt wie Du
    anfangen sollst, oder wenn Du bereits fertig bist.

public class DerRaum {

    static void starteSimulation(int anzahlGefangene, int anzahlOeffnendeSchubladen, int anzahlSimulationen) {
        int strategie1 = 0;
        int strategie2 = 0;

        for (int i = 1; i <= anzahlSimulationen; i++) {
            DerSchrank.verteileZettel(anzahlGefangene);
            if (Strategie1.zufallsFolge(anzahlGefangene, anzahlOeffnendeSchubladen) == anzahlGefangene + 1)
                strategie1++;
            if (Strategie2.permutationsFolge(anzahlGefangene, anzahlOeffnendeSchubladen) == anzahlGefangene + 1)
                strategie2++;
        }
        System.out.println("Strategie 1: " + strategie1);
        System.out.println("Strategie 2: " + strategie2);
    }

    public static void main(String[] args) {
        starteSimulation(100, 50, 1_000);
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
@author: Daniel (urbi@orbi.baby) */ // Feel free to use the code
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
