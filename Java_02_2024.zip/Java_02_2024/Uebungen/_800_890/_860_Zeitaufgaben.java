package Uebungen._800_890;

public class _860_Zeitaufgaben {

    /*
     * Zeitaufgaben
     *
     * 1. AktuellesDatum
     *    Implementiere eine Klasse AktuellesDatum mit einer Klassenmethode,
     *    die das aktuelle Datum wie in folgendem Beispiel als Zeichenkette liefert:
     *    Donnerstag, den 2.4.2020.
     *
     *
     * 2. Vergangene Zeit
     *    Berechne die Zeit in Tagen, Stunden, Minuten und Sekunden,
     *    die seit dem 1.1.2020 um 00:00:00 Uhr vergangen ist.
     *
     *
     * 3. Zeit-Differenz
     *    Realisiere eine Methode, die die Differenz zwischen zwei Datumsangaben ermittelt:
     */
    //public static int getDaysBetween(int startYear, int startMonth, int startDay,
    //                                 int endYear,   int endMonth,   int endDay)
    /*
     *
     * 4. Veronika
     *    Die Veronika ist am 28.12.2006 geboren.
     *    Wie alt ist sie heute?
     *    Wie viele Tage dauert es noch bis zum nächsten Geburtstag?
     */

}
