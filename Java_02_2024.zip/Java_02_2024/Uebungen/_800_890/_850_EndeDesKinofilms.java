package Uebungen._800_890;

public class _850_EndeDesKinofilms {

    /*
     * Ende des Kinofilms
     *
     * Ein Kinofilm beginnt um 19:30 Uhr und dauert 132 Minuten.
     * Wann ist die Vorstellung zu Ende?
     *
     */
}
