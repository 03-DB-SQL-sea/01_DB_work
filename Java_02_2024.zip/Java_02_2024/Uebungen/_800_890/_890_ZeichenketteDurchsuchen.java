package Uebungen._800_890;

public class _890_ZeichenketteDurchsuchen {

    /*
     * Zeichenkette durchsuchen
     *
     * Schreibe eine Methode findAll(), die eine Zeichenkette nach allen
     * Vorkommen einer anderen Zeichenkette durchsucht
     * und die Startpositionen als ArrayList zurückgibt.
     * Wenn es kein Vorkommen gibt, soll die ArrayList leer sein.
     * Beispiel:
     * System.out.println(findAll('abcefgabcxyzabcd', 'abc'))  // [0, 6, 12]
     */

}
