package Uebungen._800_890;

public class _800_VierstelligeZufallszahlen {

    /*
     * Vierstellige Zufallszahlen
     *
     * Schreibe ein Programm, das alle Zahlen von 0000 bis 9999
     * in zufälliger Reihenfolge in einen Container abfüllt.
     * Die Zahlen müssen alle vierstellig sein - also z.B. 0000,  0007, 0221 bzw. 8344.
     * Jede Zahl darf in dem Container am Schluss nur einmal vorkommen.
     */
}
