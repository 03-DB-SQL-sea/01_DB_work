package Uebungen._800_890;

public class _840_ArrayAsAString {

    /*
     * Array as a string
     *
     * Create in the exercise base a method called public static String arrayAsString(int[][] array).
     * It should create a string representation of the array it receives as the parameter and return it.
     *
     * Below there are a few examples of how the method is expected to work.
     */
    // int rows = 2;
    // int columns = 3;
    // int[][] matrix = new int[rows][columns];
    // matrix[0][1] = 5;
    // matrix[1][0] = 3;
    // matrix[1][2] = 7;
    // System.out.println(arrayAsString(matrix));
    //
    /*
     * Sample output:
     * 050
     * 307
     */
    // int[][] matrix = {
    //     {3, 2, 7, 6},
    //     {2, 4, 1, 0},
    //     {3, 2, 1, 0}
    // };
    //
    // System.out.println(arrayAsString(matrix));
    /*
     * Sample output:
     * 3276
     * 2410
     * 3210
     */
}
